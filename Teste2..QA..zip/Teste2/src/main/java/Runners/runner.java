
package Runners;


import io.cucumber.testng.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(

        plugin = { },
        features = {"src/main/resources/Features/Contact_Us.feature"},  //..Caimnho PATH > Root Content
        glue = {"steps"})


public class runner {
}