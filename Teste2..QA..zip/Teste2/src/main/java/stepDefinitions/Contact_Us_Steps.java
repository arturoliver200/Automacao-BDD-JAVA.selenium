package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class Contact_Us_Steps {

    private WebDriver driver;

    @Before                // Function Open ChromeDriver
    public void setup() {
        System.setProperty("web-driver.chrome.driver", System.getProperty("user.dir") + "src/main/java/Drivers/chromedriver.exe");
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        driver = new ChromeDriver(chromeOptions);
        driver.manage().window().maximize();
    }

    @After                     // Function Close ChromeDriver
    public void tearDown() {
        driver.quit();
    }


    public String generateRandomNumber(int length)
    {
        return RandomStringUtils.randomNumeric(length);
    }

    public String generateRandomString(int length) {
        return RandomStringUtils.randomAlphabetic(length);
    }



        @Given("I acess the webdriver university contact us page")  //Acess site
    public void i_acess_the_webdriver_university_contact_us_page()
    {
        driver.get("https://www.webdriveruniversity.com/Contact-Us/contactus.html");
    }

    @When("I enter a unique first name")   // Surch Xpath and Subscrive NAME ON INPUT
    public void i_enter_a_unique_first_name()
    {
        driver.findElement(By.xpath("//input[@name='first_name']")).sendKeys("BIA");
    }
    @And("I enter a unique last name")
    public void i_enter_a_unique_last_name()
    {
        driver.findElement(By.xpath("//input[@name='last_name']")).sendKeys("Jonson");
    }
    @And("I enter a unique email address")
    public void i_enter_a_unique_email_address() // Insert Email
    {
        driver.findElement(By.xpath("//input[@name='email']")).sendKeys("meu@Email");
    }



    @And("I enter a unique comment")
    public void i_enter_a_unique_comment() //Insert COMMENTS
    {
        driver.findElement(By.xpath(
                "//textarea[@name=\"message\"]")).sendKeys
                ("How Are You?.." + generateRandomString(20));

    }



    @And("I click on the submit button")
    public void i_click_on_the_submit_button() {  // Click SUBMIT
        driver.findElement(By.xpath("//input[@value=\"SUBMIT\"]")).click();
    }
    @Then("I should be presented with a sucessful contact us submission message")
    public void i_should_be_presented_with_a_sucessful_contact_us_submission_message() {
        System.out.println("teste7");
    }


}
