package Drivers;

public class test {
    private int test;

    public test(int test) {
        this.test = test;
    }
}
